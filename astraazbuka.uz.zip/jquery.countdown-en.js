(function ($) {
	$.countdown.regionalOptions['en'] = {
		labels: ['Years', 'Months', 'Weeks', ' days ', ':', ':', ''],
		labels1: ['Year', 'Month', 'Week', ' day ', ':', ':', ''],
		labels2: ['Years', 'Months', 'Weeks', ' days ', ':', ':', ''],
		compactLabels: ['y', 'm', 'w', 'd'],
		whichLabels: null,
		digits: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
		timeSeparator: ':',
		isRTL: false
	};
})(jQuery);
